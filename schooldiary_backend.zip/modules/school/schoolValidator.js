let validator = {};
validator.getschoolValidator = (req, type) => {
    // let input = {
    //     create: {
    //         schoolName: ["notEmpty", req.t("FIELD_REQUIRED", { FIELD: "school name" })],
    //         city: ["notEmpty", req.t("FIELD_REQUIRED", { FIELD: "city" })],
    //         address: ["notEmpty", req.t("FIELD_REQUIRED", { FIELD: "address" })]
    //     }
    // };
    // return input[type];
}

module.exports = validator;